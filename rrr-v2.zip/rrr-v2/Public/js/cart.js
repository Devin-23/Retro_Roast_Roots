(function () {
  //this was PAINFUL to get working but we managed some how
  const getCart = window.getCart || function () {
    try { return JSON.parse(localStorage.getItem('cart')) || []; }
    catch { return []; }
  };
  const setCart = window.setCart || function (arr) {
    localStorage.setItem('cart', JSON.stringify(arr || []));
  };
  const updateCartCount = window.updateCartCount || function () {};

  function renderCart() {
    const cart = getCart();
    const container = document.getElementById('cart-items');
    const totalEl = document.getElementById('cart-total');

    if (!Array.isArray(cart) || cart.length === 0) {
      if (container) container.innerHTML = "<p>Your cart is empty.</p>";
      if (totalEl) totalEl.textContent = "$0.00";
      updateCartCount();
      return;
    }

    //get that info!!
    let total = 0;
    const html = cart.map((item, idx) => {
      const price = Number(item.price ?? 0);
      const qty = Math.max(1, Number(item.qty || 1));
      total += price * qty;
      const img = item.img || item.image || 'img/placeholder.png';
      return `
        <div class="cart-item">
          <img src="${img}" alt="${item.name}" class="cart-item-img"
               onerror="this.onerror=null; this.src='img/placeholder.png'">
          <div class="cart-item-details">
            <h2>${item.name}</h2>
            <p>Unit: $${price.toFixed(2)}</p>
            <div class="qty-row">
              <button class="qty-btn" data-action="dec" data-index="${idx}">-</button>
              <span class="qty">${qty}</span>
              <button class="qty-btn" data-action="inc" data-index="${idx}">+</button>
            </div>
            <button class="rm-btn" data-action="remove" data-index="${idx}">Remove</button>
          </div>
        </div>
        <div class="cart-divider"></div>
      `;
    }).join("");

    if (container) container.innerHTML = html;
    if (totalEl) totalEl.textContent = "$" + total.toFixed(2);
    updateCartCount();
  }

  //adding or min the quantity
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const idx = Number(btn.getAttribute('data-index'));
    const action = btn.getAttribute('data-action');

    const cart = getCart();
    const it = cart[idx];
    if (!it) return;

    if (action === 'inc') {
      it.qty = Math.max(1, Number(it.qty || 1) + 1);
    } else if (action === 'dec') {
      it.qty = Math.max(1, Number(it.qty || 1) - 1);
    } else if (action === 'remove') {
      cart.splice(idx, 1);
    } else {
      return;
    }

    setCart(cart);
    renderCart();
  });

  document.addEventListener('DOMContentLoaded', renderCart);
})();
